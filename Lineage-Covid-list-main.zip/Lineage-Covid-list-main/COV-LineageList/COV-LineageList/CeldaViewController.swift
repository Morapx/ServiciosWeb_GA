//
//  CeldaViewController.swift
//  COV-LineageList
//
//  Created by Alumno on 21/01/22.
//  Copyright © 2022 El ruben. All rights reserved.
//

import Foundation
import UIKit

class CeldaViewController : UITableViewCell{
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblFecha: UILabel!
    @IBOutlet weak var lblNumeroDesig: UILabel!
    @IBOutlet weak var lblNumeroAsig: UILabel!
    @IBOutlet weak var lblWho: UILabel!
    
}
